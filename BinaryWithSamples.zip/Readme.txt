Just press F1 when you need help!

Input & Output format:
Input:
2 formats are supported, the FDDB(Face Detection Data Set and Benchmark) and TriLabel format.
The formats are detected automatically.

Output:
Only the TriLabel format is supported as it contains label type information.

FDDB format:
<fully qualified path name>
<# of detections in this image file>
<x y width height score>
... (for each detection) ...
<x y width height score>
... (for each file in the dataset) ...

Note: the format here includes the file extension in the file path field,
which is not included in the original FDDB format.

TriLabel format:
/* TriLabel Format */
<fully qualified path name>
<# of detections in this image file>
<label_type x y width height score>
... (for each detection) ...
<label_type x y width height score>
... (for each file in the dataset) ...

Note: the first line is always "/* TriLabel Format */" as a marking.
"label_type" ranges from 0 to 2 representing true, false, ambiguous respectively.